export const useUIStore = {};
